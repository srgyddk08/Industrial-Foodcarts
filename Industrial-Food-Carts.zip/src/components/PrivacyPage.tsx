import React from 'react';
import { User } from 'firebase/auth';
import { ArrowLeft, ArrowRight, Bell, Lock, MapPin, ShieldCheck, Truck } from 'lucide-react';
import { WorkspaceMode } from '../types';
import { PWAInstallButton } from './PWAInstallButton';

interface PrivacyPageProps {
  user: User | null;
  onNavigate: (mode: WorkspaceMode) => void;
  onSignOut: () => Promise<void>;
}

export const PrivacyPage: React.FC<PrivacyPageProps> = ({
  user,
  onNavigate,
  onSignOut,
}) => {
  const pushStatus =
    typeof window !== 'undefined' && 'Notification' in window
      ? Notification.permission
      : 'unsupported';

  return (
    <div className="min-h-screen flex flex-col bg-slate-50 text-slate-900">
      {/* Top Bar Contract: Brand wordmark — 4 concise single-line links — 1 primary action */}
      <header className="sticky top-0 z-40 bg-white/95 backdrop-blur border-b border-slate-200">
        <div className="max-w-7xl mx-auto px-6 py-4 flex items-center justify-between gap-8">
          <button
            type="button"
            onClick={() => onNavigate('landing')}
            className="font-display text-lg font-bold tracking-tight text-slate-900 whitespace-nowrap shrink-0 text-left"
          >
            Industrial Foodcarts
          </button>

          <nav className="hidden md:flex items-center gap-6 text-sm font-medium text-slate-600">
            <a
              href="#overview"
              className="hover:text-slate-900 transition-colors whitespace-nowrap shrink-0"
            >
              Overview
            </a>
            <a
              href="#location-gps"
              className="hover:text-slate-900 transition-colors whitespace-nowrap shrink-0"
            >
              Location &amp; GPS
            </a>
            <a
              href="#data-access"
              className="hover:text-slate-900 transition-colors whitespace-nowrap shrink-0"
            >
              Data Access
            </a>
            <a
              href="#user-controls"
              className="hover:text-slate-900 transition-colors whitespace-nowrap shrink-0"
            >
              Your Controls
            </a>
          </nav>

          <div className="flex items-center gap-3 shrink-0">
            <PWAInstallButton variant="subtle" />
            <button
              type="button"
              onClick={() => onNavigate('landing')}
              className="inline-flex items-center gap-1.5 px-4 py-2 text-xs font-medium text-white bg-slate-900 rounded-lg hover:bg-slate-800 transition-colors whitespace-nowrap shrink-0"
            >
              <ArrowLeft className="w-3.5 h-3.5" />
              <span>Back to Home</span>
            </button>
          </div>
        </div>
      </header>

      <main className="flex-1">
        {/* Header Band */}
        <section id="overview" className="border-b border-slate-200 bg-white">
          <div className="max-w-4xl mx-auto px-6 py-12 lg:py-16">
            <div className="flex flex-wrap items-center gap-2 text-xs font-medium text-orange-600 tabular-nums">
              <span>Privacy Policy</span>
              <span aria-hidden="true">·</span>
              <span>Effective November 16, 2026</span>
              <span aria-hidden="true">·</span>
              <span>Industrial Foodcarts</span>
            </div>

            <h1 className="mt-3 font-display text-3xl sm:text-5xl font-bold tracking-tight text-slate-900 leading-[1.08] [text-wrap:balance]">
              How Industrial Foodcarts handles your location, orders, and account data
            </h1>

            <p className="mt-4 text-base text-slate-600 leading-relaxed max-w-2xl">
              This policy explains what information Industrial Foodcarts processes when you search
              for mobile foodcarts near workplaces and industrial corridors, submit location stop
              requests, place window pre-orders, or broadcast live vendor GPS telemetry.
            </p>
          </div>
        </section>

        {/* Main Policy Sections */}
        <div className="max-w-4xl mx-auto px-6 py-12 space-y-10">
          {/* 01. Information Collected */}
          <section className="bg-white border border-slate-200 rounded-xl p-6 sm:p-8 space-y-4">
            <div className="flex items-center gap-2 text-slate-900">
              <ShieldCheck className="w-5 h-5 text-orange-600 shrink-0" />
              <h2 className="font-display text-xl font-bold tracking-tight">
                01. Information You Provide &amp; Account Identity
              </h2>
            </div>
            <p className="text-sm text-slate-600 leading-relaxed">
              You can browse listed foodcarts, menus, scheduled routes, and live stop timers
              without creating an account. When you sign in with Google via Firebase Authentication
              to save favorites, submit pre-orders, request a cart to a location, or operate a
              vendor console, we process:
            </p>
            <ul className="space-y-2.5 text-sm text-slate-700 leading-relaxed list-disc pl-5">
              <li>
                <span className="font-semibold text-slate-900">Authentication Identity:</span> Your
                Firebase user ID, display name, and email verification state provided by Google
                Sign-In. Email addresses are used solely by Firebase Authentication and are not
                published in public foodcart listings, pre-orders, or location requests.
              </li>
              <li>
                <span className="font-semibold text-slate-900">Profile &amp; Preferences:</span>{' '}
                Your display name, preferred role (<span className="font-mono text-xs">customer</span>{' '}
                or <span className="font-mono text-xs">owner</span>), default radar search radius,
                notification preference, and saved favorite carts.
              </li>
              <li>
                <span className="font-semibold text-slate-900">Pre-Orders &amp; Stop Requests:</span>{' '}
                When placing a pre-order, we store the selected items, total, pickup note, and your
                display name. When inviting a foodcart to a location, we store your chosen street
                label or coordinates, requested arrival window, estimated headcount, and optional
                notes.
              </li>
              <li>
                <span className="font-semibold text-slate-900">Vendor Storefront Listings:</span>{' '}
                Foodcart owners provide a cart name, optional food nationality, cuisine type,
                description, cover and gallery photos, menu items, scheduled route stops, live
                service countdowns, and broadcast messages for public discovery.
              </li>
            </ul>
          </section>

          {/* 02. Location & GPS */}
          <section
            id="location-gps"
            className="bg-white border border-slate-200 rounded-xl p-6 sm:p-8 space-y-4"
          >
            <div className="flex items-center gap-2 text-slate-900">
              <MapPin className="w-5 h-5 text-orange-600 shrink-0" />
              <h2 className="font-display text-xl font-bold tracking-tight">
                02. Geolocation, Live GPS Telemetry &amp; Mapping Services
              </h2>
            </div>
            <p className="text-sm text-slate-600 leading-relaxed">
              Location access is explicit and optional. We never collect background device GPS when
              the app is closed, and you may pause or revoke location access at any time.
            </p>
            <ul className="space-y-2.5 text-sm text-slate-700 leading-relaxed list-disc pl-5">
              <li>
                <span className="font-semibold text-slate-900">Customer Proximity Radar:</span>{' '}
                Clicking <span className="font-medium text-slate-900">Single Fix</span> or{' '}
                <span className="font-medium text-slate-900">Start Live GPS Stream</span> uses your
                browser&apos;s Geolocation API to center the map and compute walking or driving
                distances locally. You can always type a street address or click anywhere on the map
                instead of sharing device GPS.
              </li>
              <li>
                <span className="font-semibold text-slate-900">Vendor Curb Broadcasts:</span>{' '}
                When a foodcart owner sets a live stop or turns on Live GPS Stream, the cart&apos;s
                coordinates, GPS accuracy circle, heading, speed, and stop label are stored in
                Cloud Firestore (<span className="font-mono text-xs">telemetry/live</span>) so
                customers can view the cart&apos;s active position and trail on the map.
              </li>
              <li>
                <span className="font-semibold text-slate-900">Google Maps Platform:</span> Map
                tiles, place search suggestions, nearby place lookups, and route travel-time
                calculations are powered by the Google Maps Platform JavaScript SDK. Use of map
                features is subject to the{' '}
                <a
                  href="https://maps.google.com/help/terms_maps/"
                  target="_blank"
                  rel="noopener noreferrer"
                  className="text-orange-600 font-medium underline hover:text-orange-700"
                >
                  Google Maps Platform End User Terms
                </a>{' '}
                and the{' '}
                <a
                  href="https://policies.google.com/privacy"
                  target="_blank"
                  rel="noopener noreferrer"
                  className="text-orange-600 font-medium underline hover:text-orange-700"
                >
                  Google Privacy Policy
                </a>
                .
              </li>
            </ul>
          </section>

          {/* 03. Notifications */}
          <section className="bg-white border border-slate-200 rounded-xl p-6 sm:p-8 space-y-4">
            <div className="flex items-center gap-2 text-slate-900">
              <Bell className="w-5 h-5 text-orange-600 shrink-0" />
              <h2 className="font-display text-xl font-bold tracking-tight">
                03. Proximity Push Notifications
              </h2>
            </div>
            <p className="text-sm text-slate-600 leading-relaxed">
              Browser push notifications are triggered locally on your device only after you grant
              explicit notification permission and only for favorited carts or live broadcasts
              within your selected search radius. No advertising trackers or third-party push
              brokers are used.
            </p>
          </section>

          {/* 04. Data Visibility & Access Matrix */}
          <section
            id="data-access"
            className="bg-white border border-slate-200 rounded-xl p-6 sm:p-8 space-y-4"
          >
            <div className="flex items-center gap-2 text-slate-900">
              <Lock className="w-5 h-5 text-orange-600 shrink-0" />
              <h2 className="font-display text-xl font-bold tracking-tight">
                04. Who Can See Your Data (Firestore Isolation)
              </h2>
            </div>
            <p className="text-sm text-slate-600 leading-relaxed">
              Access to every Cloud Firestore collection is enforced directly by server-side
              security rules:
            </p>

            <div className="overflow-x-auto border border-slate-200 rounded-lg">
              <table className="w-full text-left border-collapse text-sm">
                <thead>
                  <tr className="bg-slate-50 border-b border-slate-200 text-xs font-semibold text-slate-700">
                    <th className="py-3 px-4">Data Record</th>
                    <th className="py-3 px-4">Who Can Read</th>
                    <th className="py-3 px-4">Who Can Modify</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-slate-200 text-slate-700">
                  <tr>
                    <td className="py-3 px-4 font-medium text-slate-900">
                      User profile &amp; favorite carts
                    </td>
                    <td className="py-3 px-4">Only your signed-in account</td>
                    <td className="py-3 px-4">Only your signed-in account</td>
                  </tr>
                  <tr>
                    <td className="py-3 px-4 font-medium text-slate-900">
                      Customer pre-orders
                    </td>
                    <td className="py-3 px-4">Only the placing customer &amp; cart owner</td>
                    <td className="py-3 px-4">
                      Customer (cancel pending) &amp; cart owner (fulfillment status)
                    </td>
                  </tr>
                  <tr>
                    <td className="py-3 px-4 font-medium text-slate-900">
                      Location stop requests
                    </td>
                    <td className="py-3 px-4">Only the requesting customer &amp; cart owner</td>
                    <td className="py-3 px-4">
                      Customer (cancel pending) &amp; cart owner (approve / deny)
                    </td>
                  </tr>
                  <tr>
                    <td className="py-3 px-4 font-medium text-slate-900">
                      Listed foodcarts, menus, routes &amp; live telemetry
                    </td>
                    <td className="py-3 px-4">Public when listed (unlisted carts: owner only)</td>
                    <td className="py-3 px-4">Verified cart owner only</td>
                  </tr>
                </tbody>
              </table>
            </div>
          </section>

          {/* 05. User Choices & Controls */}
          <section
            id="user-controls"
            className="bg-white border border-slate-200 rounded-xl p-6 sm:p-8 space-y-5"
          >
            <div className="flex items-center gap-2 text-slate-900">
              <Truck className="w-5 h-5 text-orange-600 shrink-0" />
              <h2 className="font-display text-xl font-bold tracking-tight">
                05. Your Privacy Choices &amp; Controls
              </h2>
            </div>

            <div className="grid sm:grid-cols-2 gap-4 text-sm text-slate-600 leading-relaxed">
              <div className="p-4 bg-slate-50 border border-slate-200 rounded-lg space-y-1.5">
                <div className="font-display font-semibold text-slate-900">
                  Stop Location &amp; GPS Sharing
                </div>
                <p>
                  Click <span className="font-medium text-slate-900">Stop Live Stream</span> inside
                  any workspace or disable location permissions for this site in your browser&apos;s
                  site settings panel.
                </p>
              </div>

              <div className="p-4 bg-slate-50 border border-slate-200 rounded-lg space-y-1.5">
                <div className="font-display font-semibold text-slate-900">
                  Manage Incoming Stop Requests
                </div>
                <p>
                  Foodcart owners can toggle customer location requests{' '}
                  <span className="font-medium text-slate-900">On or Off</span> per cart and unlist
                  or delete any cart, menu item, or route stop from the Vendor Console.
                </p>
              </div>

              <div className="p-4 bg-slate-50 border border-slate-200 rounded-lg space-y-1.5">
                <div className="font-display font-semibold text-slate-900">
                  Cancel Requests &amp; Pending Orders
                </div>
                <p>
                  Customers can cancel pending pre-orders or location requests anytime from the
                  Orders or Requests drawer and remove saved favorite carts.
                </p>
              </div>

              <div className="p-4 bg-slate-50 border border-slate-200 rounded-lg space-y-1.5">
                <div className="font-display font-semibold text-slate-900">
                  Browser Session &amp; Alerts
                </div>
                <p className="tabular-nums">
                  Current browser notification permission:{' '}
                  <span className="font-mono text-xs font-semibold text-slate-900">
                    {pushStatus}
                  </span>
                  . Account status:{' '}
                  <span className="font-medium text-slate-900">
                    {user ? user.email || 'Signed in' : 'Browsing as guest'}
                  </span>
                  .
                </p>
              </div>
            </div>

            <div className="pt-2 flex flex-wrap items-center gap-3">
              <button
                type="button"
                onClick={() => onNavigate('customer')}
                className="inline-flex items-center gap-1.5 px-4 py-2 text-xs font-semibold text-white bg-orange-600 rounded-lg hover:bg-orange-700 transition-colors whitespace-nowrap shrink-0"
              >
                <span>Open Customer Map</span>
                <ArrowRight className="w-3.5 h-3.5" />
              </button>
              <button
                type="button"
                onClick={() => onNavigate('owner')}
                className="inline-flex items-center gap-1.5 px-4 py-2 text-xs font-semibold text-slate-900 bg-slate-100 border border-slate-200 rounded-lg hover:bg-slate-200 transition-colors whitespace-nowrap shrink-0"
              >
                <span>Open Vendor Console</span>
              </button>
              {user && (
                <button
                  type="button"
                  onClick={() => void onSignOut()}
                  className="inline-flex items-center gap-1.5 px-4 py-2 text-xs font-medium text-slate-700 bg-white border border-slate-200 rounded-lg hover:bg-slate-50 transition-colors whitespace-nowrap shrink-0"
                >
                  <span>Sign Out</span>
                </button>
              )}
            </div>
          </section>
        </div>
      </main>

      {/* Quiet Footer */}
      <footer className="border-t border-slate-200 bg-white">
        <div className="max-w-7xl mx-auto px-6 py-6 flex flex-wrap items-center justify-between gap-4 text-xs text-slate-500">
          <span className="font-display font-semibold text-slate-900">Industrial Foodcarts</span>
          <div className="flex flex-wrap items-center gap-5">
            <button
              type="button"
              onClick={() => onNavigate('landing')}
              className="hover:text-slate-900 transition-colors whitespace-nowrap shrink-0"
            >
              Home
            </button>
            <button
              type="button"
              onClick={() => onNavigate('customer')}
              className="hover:text-slate-900 transition-colors whitespace-nowrap shrink-0"
            >
              Customer Map
            </button>
            <button
              type="button"
              onClick={() => onNavigate('owner')}
              className="hover:text-slate-900 transition-colors whitespace-nowrap shrink-0"
            >
              Vendor Console
            </button>
          </div>
        </div>
      </footer>
    </div>
  );
};
